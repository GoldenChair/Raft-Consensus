package lvc.cds.raftClient;

import java.util.Scanner;


public class App {
    public static void main(String[] args) 
    {
        boolean shouldQuit = false;
        Scanner inputReader = new Scanner(System.in);
        System.out.println("Enter leader ip");
        String leaderIP = inputReader.nextLine();
        System.out.println("Enter port");
        int leaderPort = Integer.parseInt(inputReader.nextLine());

        RaftStub rStub = new RaftStub(leaderIP, leaderPort);
        rStub.connect();
        System.out.println("Connected.");
        while(true)
        {
            if(shouldQuit)
                break;
            System.out.println("Enter a command to the leader.  Enter HELP for help.");
            String leaderCommand = inputReader.nextLine();
            switch(leaderCommand)
            {
                case "HELP":
                {
                    System.out.println("List of commands:");
                    System.out.println("HELP - Pulls up this menu");
                    System.out.println("ADD - Takes a key and a value, adds a key value pair to the KVS");
                    System.out.println("DEL - Takes a key and deletes everything under it");
                    System.out.println("CHANGE - Allows you to change the leader to send messages to");
                    System.out.println("QUIT - Closes the client");
                    break;
                }
                case "ADD":
                {
                    System.out.println("Enter key");
                    String key = inputReader.nextLine();
                    System.out.println("Enter field");
                    String field = inputReader.nextLine();
                    System.out.println("Enter value");
                    String value = inputReader.nextLine();
                    String sentCommand = "ADD " + key + " " + field + " " + value;
                    rStub.sendClientMessage(sentCommand);
                    System.out.println("Command sent: " + sentCommand);
                    break;
                }
                case "DEL":
                {
                    System.out.println("Enter key");
                    String key = inputReader.nextLine();
                    String sentCommand = "DEL " + key;
                    rStub.sendClientMessage(sentCommand);
                    System.out.println("Command sent: " + sentCommand);
                    break;
                }
                case "CHANGE":
                {
                    try
                    {
                        rStub.shutdown();
                        System.out.println("Enter leader ip");
                        leaderIP = inputReader.nextLine();
                        System.out.println("Enter port");
                        leaderPort = Integer.parseInt(inputReader.nextLine());
                        rStub = new RaftStub(leaderIP, leaderPort);
                        rStub.connect();
                        System.out.println("Connected.");
                    }
                    catch(Exception e)
                    {
                        System.out.println("An unexpected error occurred.");
                    }
                    break;
                }
                case "QUIT":
                {
                    shouldQuit = true;
                    break;
                }
                default:
                {
                    System.out.println("Command not recognized.");
                    break;
                }
            }
        }
        try
        {
            rStub.shutdown();
        }
        catch(Exception e){}
        inputReader.close();
    }
}
